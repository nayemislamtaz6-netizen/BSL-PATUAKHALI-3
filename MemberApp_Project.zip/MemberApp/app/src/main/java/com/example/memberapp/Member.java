package com.example.memberapp;

public class Member {
    public String id, name, mobile, role, status;

    public Member() {}

    public Member(String id, String name, String mobile, String role, String status) {
        this.id = id;
        this.name = name;
        this.mobile = mobile;
        this.role = role;
        this.status = status;
    }
}