package com.example.memberapp;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {
    private EditText etName, etMobile;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etName = findViewById(R.id.etName);
        etMobile = findViewById(R.id.etMobile);
        dbRef = FirebaseDatabase.getInstance().getReference("Members");

        findViewById(R.id.btnSubmitReg).setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String mobile = etMobile.getText().toString().trim();

            if (!name.isEmpty() && !mobile.isEmpty()) {
                String id = dbRef.push().getKey();
                Member member = new Member(id, name, mobile, "সদস্য", "Pending");
                if (id != null) {
                    dbRef.child(id).setValue(member);
                    Toast.makeText(this, "আবেদন সফল!", Toast.LENGTH_LONG).show();
                    finish();
                }
            } else {
                Toast.makeText(this, "সব তথ্য পূরণ করুন", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }
}