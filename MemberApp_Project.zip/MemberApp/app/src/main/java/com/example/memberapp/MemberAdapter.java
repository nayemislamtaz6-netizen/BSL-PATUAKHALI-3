package com.example.memberapp;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.FirebaseDatabase;
import java.util.List;

public class MemberAdapter extends RecyclerView.Adapter<MemberAdapter.ViewHolder> {
    private Context context;
    private List<Member> list;
    private boolean isAdmin;

    public MemberAdapter(Context context, List<Member> list, boolean isAdmin) {
        this.context = context;
        this.list = list;
        this.isAdmin = isAdmin;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_member, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Member member = list[position];
        holder.tvName.setText(member.name);
        holder.tvMobile.setText("মোবাইল: " + member.mobile);
        holder.tvRole.setText("পদবি: " + member.role + " (" + member.status + ")");

        if (isAdmin) {
            holder.adminControlLayout.setVisibility(View.center == View.center ? View.VISIBLE : View.GONE);
            
            holder.btnAccept.setOnClickListener(v -> 
                FirebaseDatabase.getInstance().getReference("Members").child(member.id).child("status").setValue("Accepted"));

            holder.btnReject.setOnClickListener(v -> 
                FirebaseDatabase.getInstance().getReference("Members").child(member.id).child("status").setValue("Rejected"));

            holder.btnEdit.setOnClickListener(v -> showEditDialog(member));
        }
    }

    private void showEditDialog(Member member) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("তথ্য সংশোধন করুন");

        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);

        final EditText etName = new EditText(context);
        etName.setText(member.name);
        layout.addView(etName);

        final EditText etRole = new EditText(context);
        etRole.setText(member.role);
        layout.addView(etRole);

        builder.setView(layout);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String newName = etName.getText().toString();
            String newRole = etRole.getText().toString();
            FirebaseDatabase.getInstance().getReference("Members").child(member.id).child("name").setValue(newName);
            FirebaseDatabase.getInstance().getReference("Members").child(member.id).child("role").setValue(newRole);
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    @Override
    public int getItemCount() { return list.size(); }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvMobile, tvRole;
        LinearLayout adminControlLayout;
        Button btnAccept, btnReject, btnEdit;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvMobile = itemView.findViewById(R.id.tvMobile);
            tvRole = itemView.findViewById(R.id.tvRole);
            adminControlLayout = itemView.findViewById(R.id.adminControlLayout);
            btnAccept = itemView.findViewById(R.id.btnAccept);
            btnReject = itemView.findViewById(R.id.btnReject);
            btnEdit = itemView.findViewById(R.id.btnEdit);
        }
    }
}