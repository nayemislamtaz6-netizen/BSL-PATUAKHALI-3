package com.example.memberapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        EditText etUser = findViewById(R.id.etName);
        EditText etPass = findViewById(R.id.etMobile);
        Button btnLogin = findViewById(R.id.btnSubmitReg);

        etUser.setHint("অ্যাডমিন ইউজারনেম");
        etPass.setHint("পাসওয়ার্ড");
        etPass.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        btnLogin.setText("Login");

        btnLogin.setOnClickListener(v -> {
            if(etUser.getText().toString().equals("admin") && etPass.getText().toString().equals("admin123")) {
                startActivity(new Intent(LoginActivity.this, AdminDashboardActivity.class));
                finish();
            } else {
                Toast.makeText(this, "ভুল ইউজারনেম বা পাসওয়ার্ড!", Toast.LENGTH_SHORT).show();
            }
        });
        
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }
}